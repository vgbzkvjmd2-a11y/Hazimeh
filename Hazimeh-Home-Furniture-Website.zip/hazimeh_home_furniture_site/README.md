# Hazimeh Home Furniture — Website

This is a static, responsive website ready for GitHub Pages or any static web host.

## Included
- Hazimeh Home Furniture branding
- Home / Office / Home Furniture / Sofas & Seating / Tables / Storage / New Arrivals navigation
- The sofa photos you provided, organized under Sofas & Seating
- The bedroom/home-furniture photos you provided, organized under Home Furniture
- Responsive mobile layout
- Product search
- Inquiry/cart counter
- Placeholder areas for office, tables and storage products
- Contact section

## Before publishing
Open `index.html` and `script.js` if you want to replace the placeholder email/WhatsApp details.

## GitHub Pages
Upload the contents of this folder to a GitHub repository and enable GitHub Pages from Settings → Pages. GitHub Pages can publish a static `index.html` site directly from a repository.
